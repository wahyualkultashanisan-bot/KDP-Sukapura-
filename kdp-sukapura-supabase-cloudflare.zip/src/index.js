const enc=new TextEncoder();
async function hmac(v,s){const k=await crypto.subtle.importKey("raw",enc.encode(s),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return new Uint8Array(await crypto.subtle.sign("HMAC",k,enc.encode(v)))}
function b64(b){let s="";for(const x of b)s+=String.fromCharCode(x);return btoa(s).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
function unb(s){s=s.replace(/-/g,"+").replace(/_/g,"/");while(s.length%4)s+="=";let x=atob(s);return Uint8Array.from(x,c=>c.charCodeAt(0))}
async function session(email,secret){let p=b64(enc.encode(JSON.stringify({e:email,exp:Date.now()+28800000})));return p+"."+b64(await hmac(p,secret))}
async function valid(req,secret){try{let m=req.headers.get("Cookie")?.match(/(?:^|;\s*)kdp_session=([^;]+)/);if(!m||!secret)return false;let [p,s]=m[1].split("."),a=unb(s),b=await hmac(p,secret);if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a[i]^b[i];if(d)return false;return JSON.parse(new TextDecoder().decode(unb(p))).exp>Date.now()}catch{return false}}
const j=(x,s=200,h={})=>new Response(JSON.stringify(x),{status:s,headers:{"content-type":"application/json",...h}});
export default {async fetch(req,env){let u=new URL(req.url);
if(u.pathname==="/api/login"&&req.method==="POST"){let {email,password}=await req.json();if(email!==env.ADMIN_EMAIL||password!==env.ADMIN_PASSWORD)return j({ok:false,error:"Email atau password salah."},401);let c=await session(email,env.SESSION_SECRET);return j({ok:true},200,{"Set-Cookie":`kdp_session=${c}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=28800`})}
if(u.pathname==="/api/logout")return j({ok:true},200,{"Set-Cookie":"kdp_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0"});
if(u.pathname==="/api/me")return j({authenticated:await valid(req,env.SESSION_SECRET)});
if(u.pathname==="/admin"||u.pathname==="/admin/"){if(!await valid(req,env.SESSION_SECRET))return new Response(null,{status:302,headers:{Location:"/login.html"}});return env.ASSETS.fetch(new Request(new URL("/admin.html",req.url),req))}
return env.ASSETS.fetch(req)}}