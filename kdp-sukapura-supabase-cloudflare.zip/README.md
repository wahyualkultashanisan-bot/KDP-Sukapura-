# KDP Sukapura — Supabase + Cloudflare

Versi ini disiapkan untuk Cloudflare Workers + Static Assets dan Supabase.

PENTING:
- Supabase dipakai untuk database konten. Login admin pada versi ini tetap melalui Cloudflare Worker agar password tidak ditaruh di browser.
- Jangan pernah memasukkan `sb_secret_...` atau `service_role` ke file frontend.
- Set Cloudflare secrets/variables:
  ADMIN_EMAIL
  ADMIN_PASSWORD (Secret)
  SESSION_SECRET (Secret, string acak panjang)
- Jalankan `supabase.sql` di Supabase SQL Editor.

Deploy:
npx wrangler deploy

Cloudflare akan memberikan URL workers.dev setelah deployment.
